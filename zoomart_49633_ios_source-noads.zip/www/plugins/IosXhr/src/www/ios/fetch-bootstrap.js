cordova.define("IosXhr.fetch-bootstrap", function(require, exports, module) {
'use strict';

(function ()
{
  var _fetch = window.fetch;
  window.fetch = undefined;
})();

});
